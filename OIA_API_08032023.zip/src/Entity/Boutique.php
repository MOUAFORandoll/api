<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\BoutiqueRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * 
 * @ORM\Entity(repositoryClass=BoutiqueRepository::class)
 */
class Boutique
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $titre;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(type="boolean") 
     */
    private $status = false;
    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $codeBoutique;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $dateCreated;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="boutiques")
     */
    private $user;

    /**
     * @ORM\OneToMany(targetEntity=Produit::class, mappedBy="boutique")
     */
    private $produits;

    /**
     * @ORM\OneToMany(targetEntity=BoutiqueObject::class, mappedBy="boutique")
     */
    private $boutiqueObjects;

    /**
     * @ORM\ManyToOne(targetEntity=Localisation::class, inversedBy="boutiques")
     */
    private $localisation;

    /**
     * @ORM\ManyToOne(targetEntity=Category::class, inversedBy="boutiques")
     */
    private $category;

    /**
     * @ORM\OneToMany(targetEntity=Short::class, mappedBy="boutique")
     */
    private $shorts;


    public function __construct()
    {
        $this->dateCreated = new \DateTime();
        $this->produits = new ArrayCollection();
        $this->boutiqueObjects = new ArrayCollection();
        $this->shorts = new ArrayCollection();
    }
    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitre(): ?string
    {
        return $this->titre;
    }

    public function setTitre(string $titre): self
    {
        $this->titre = $titre;

        return $this;
    }

    public function getCodeBoutique(): ?string
    {
        return $this->codeBoutique;
    }

    public function setCodeBoutique(?string $codeBoutique): self
    {
        $this->codeBoutique = $codeBoutique;

        return $this;
    }


    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getDateCreated(): ?\DateTimeInterface
    {
        return $this->dateCreated;
    }

    public function setDateCreated(?\DateTimeInterface $dateCreated): self
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }



    public function isStatus(): ?bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): self
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return Collection<int, Produit>
     */
    public function getProduits(): Collection
    {
        return $this->produits;
    }

    public function addProduit(Produit $produit): self
    {
        if (!$this->produits->contains($produit)) {
            $this->produits[] = $produit;
            $produit->setBoutique($this);
        }

        return $this;
    }

    public function removeProduit(Produit $produit): self
    {
        if ($this->produits->removeElement($produit)) {
            // set the owning side to null (unless already changed)
            if ($produit->getBoutique() === $this) {
                $produit->setBoutique(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, BoutiqueObject>
     */
    public function getBoutiqueObjects(): Collection
    {
        return $this->boutiqueObjects;
    }

    public function addBoutiqueObject(BoutiqueObject $boutiqueObject): self
    {
        if (!$this->boutiqueObjects->contains($boutiqueObject)) {
            $this->boutiqueObjects[] = $boutiqueObject;
            $boutiqueObject->setBoutique($this);
        }

        return $this;
    }

    public function removeBoutiqueObject(BoutiqueObject $boutiqueObject): self
    {
        if ($this->boutiqueObjects->removeElement($boutiqueObject)) {
            // set the owning side to null (unless already changed)
            if ($boutiqueObject->getBoutique() === $this) {
                $boutiqueObject->setBoutique(null);
            }
        }

        return $this;
    }

    public function getLocalisation(): ?Localisation
    {
        return $this->localisation;
    }

    public function setLocalisation(?Localisation $localisation): self
    {
        $this->localisation = $localisation;

        return $this;
    }

    public function getCategory(): ?Category
    {
        return $this->category;
    }

    public function setCategory(?Category $category): self
    {
        $this->category = $category;

        return $this;
    }

    /**
     * @return Collection<int, Short>
     */
    public function getShorts(): Collection
    {
        return $this->shorts;
    }

    public function addShort(Short $short): self
    {
        if (!$this->shorts->contains($short)) {
            $this->shorts[] = $short;
            $short->setBoutique($this);
        }

        return $this;
    }

    public function removeShort(Short $short): self
    {
        if ($this->shorts->removeElement($short)) {
            // set the owning side to null (unless already changed)
            if ($short->getBoutique() === $this) {
                $short->setBoutique(null);
            }
        }

        return $this;
    }
}
