<?php

namespace App\Controller;

use App\Entity\Compte;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Gesdinet\JWTRefreshTokenBundle\Model\RefreshTokenManagerInterface;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use Swift_Mailer;
use Swift_SendmailTransport;
use Swift_SmtpTransport;
use Swift_Transport;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Mailer\Bridge\Google\Transport\GmailSmtpTransport;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Mailer\Transport;
use Symfony\Component\Mailer\Mailer;
use Symfony\Component\Mime\RawMessage;
use Symfony\Component\String\Slugger\SluggerInterface;
use App\FunctionU\MyFunction;
use Doctrine\Persistence\ManagerRegistry;

use App\Entity\Connexion;
use App\Entity\User;
use App\Entity\Localisation;
use DateTime;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\DecodingExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;


class UserManageController extends AbstractController
{

    private $em;
    private $mailer;
    private $user;
    private $passwordEncoder;
    private $jwt;
    private $jwtRefresh;
    private $validator;
    private $myFunction;

    public function __construct(
        EntityManagerInterface $em,
        MailerInterface $mailer,
        HttpClientInterface $user,
        UserPasswordEncoderInterface $passwordEncoder,
        UserPasswordHasherInterface $passwordHasher,
        JWTTokenManagerInterface $jwt,
        RefreshTokenManagerInterface $jwtRefresh,
        ValidatorInterface
        $validator,
        MyFunction  $myFunction
    ) {
        $this->em = $em;
        $this->myFunction = $myFunction;
        $this->user = $user;
        $this->passwordEncoder = $passwordEncoder;
        $this->passwordEncoder = $passwordEncoder;
        $this->jwt = $jwt;
        $this->jwtRefresh = $jwtRefresh;
        $this->validator = $validator;
        $this->mailer = $mailer;
    }


    /**
     * @Route("/user/get", name="getUserX", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     */
    public function getUserX(Request $request)
    {
        $data = $request->toArray();
        if (empty($data['keySecret'])) {
            return new JsonResponse([
                'message' => 'Veuillez recharger la page et reessayer '
            ], 203);
        }
        $user = $this->em->getRepository(User::class)->findOneBy(['keySecret' => $data['keySecret']]);
        $serializer = $this->get('serializer');
        $compte = $this->em->getRepository(Compte::class)->findOneBy(['user' => $user]);


        if (!$user) {
            return new JsonResponse([
                'message' => 'Desolez l\'utilisateur en question a des contraintes',

            ], 203);
        }
        $localisation = $user->getLocalisations()[count($user->getLocalisations()) - 1];
        $userU = [
            'id' => $user->getId(),
            'nom' => $user->getNom(), 'prenom' => $user->getPrenom(),
            'email' => $user->getEmail(), 'phone' => $user->getPhone(),
            'status' => $user->isStatus(),
            'typeUser' => $user->getTypeUser()->getId(),
            'dateCreated' => date_format($user->getDateCreated(), 'Y-m-d H:i'),
            'localisation' =>    $localisation  ? [
                'ville' =>
                $localisation->getVille(),

                'longitude' =>
                $localisation->getLongitude(),
                'latitude' =>
                $localisation->getLatitude(),
            ] : []
            // 'nom' => $user->getNom()
        ];
        $compteU =  $compte  ? [
            'id' => $compte->getId(),
            'solde' => $compte->getSolde() ?? 0,
        ] : [
            'id' => 0,
            'solde' =>  0,
        ];


        return new JsonResponse([
            // 'status' => 'ok',
            'data' =>  $userU,
            'compte' =>  $compteU,
        ], 200);
    }
    /**
     * @Route("/user/update", name="updateProfilClient", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     */
    public function updateProfilClient(Request $request)
    {
        $data = $request->toArray();
        if (empty($data['keySecret'])) {
            return new JsonResponse([
                'message' => 'Veuillez recharger la page et reessayer '
            ], 400);
        }
        $user = $this->em->getRepository(User::class)->findOneBy(['keySecret' => $data['keySecret']]);

        if (!$user) {
            return new JsonResponse([
                'message' => 'Desolez l\'utilisateur en question n\'existe pas dans la base de donnée'
            ], 400);
        }

        if (!empty($data['nom'])) {
            $user->setNom($data['nom']);
        }

        if (!empty($data['prenom'])) {
            $user->setPrenom($data['prenom']);
        }
        if (!empty($data['email'])) {
            $user->setEmail($data['email']);
        }


        if (!empty($data['phone'])) {
            $user->setPhone($data['phone']);
        }


        $this->em->persist($user);
        $this->em->flush();

        $infoUser = $this->createNewJWT($user);
        $tokenAndRefresh = json_decode($infoUser->getContent());

        return new JsonResponse([
            'message' => 'success',
            'token' => $tokenAndRefresh->token,
            'refreshToken' => $tokenAndRefresh->refreshToken,
        ], 200);
    }

    public function getNewPssw(/* $id */)
    {

        $chaine = '';
        $listeCar = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $max = mb_strlen($listeCar, '8bit') - 1;
        for ($i = 0; $i < 5; ++$i) {
            $chaine .= $listeCar[random_int(0, $max)];
        }

        $chaine .= '@';
        for ($i = 0; $i < 2; ++$i) {
            $chaine .= $listeCar[random_int(0, $max)];
        }
        // $user = $this->em->getRepository(User::class)->findOneBy(['id' => $id]);
        // $password = $this->passwordHasher->hashPassword(
        //     $user,
        //     $chaine
        // );
        // $user->setPassword($password);

        return $chaine;
    }
    /**
     * @Route("/update/password/user", name="updatePasswordClient", methods={"PATCH"})
     * @param Request $request
     * @return JsonResponse
     */
    public function updatePasswordClient(Request $request)
    {
        $data = $request->toArray();
        if (empty($data['userId'])) {
            return new JsonResponse([
                'message' => 'Veuillez recharger la page et reessayerle userId et password sont requis'
            ], 400);
        }
        $user = $this->em->getRepository(User::class)->find((int)$data['userId']);

        if (!$user) {
            return new JsonResponse([
                'message' => 'Desolez l\'utilisateur en question n\'existe pas dans la base de donnée'
            ], 400);
        }
        $npass = $data['password'] ?? $this->getNewPssw();

        $password = $this->passwordEncoder->encodePassword(
            $user,
            $npass
        );
        $user->setPassword($password);
        $user->setFirstConnexion(false);
        $this->em->persist($user);
        $this->em->flush();

        $infoUser = $this->createNewJWT($user);
        $tokenAndRefresh = json_decode($infoUser->getContent());

        return new JsonResponse([
            'password' => $npass,
            'token' => $tokenAndRefresh->token,
            'refreshToken' => $tokenAndRefresh->refreshToken,
        ], 200);
    }
    public function createNewJWT(User $user)
    {
        $token = $this->jwt->create($user);

        $datetime = new \DateTime();
        $datetime->modify('+2592000 seconds');

        $refreshToken = $this->jwtRefresh->create();

        $refreshToken->setUsername($user->getUsername());
        $refreshToken->setRefreshToken();
        $refreshToken->setValid($datetime);

        // Validate, that the new token is a unique refresh token
        $valid = false;
        while (false === $valid) {
            $valid = true;
            $errors = $this->validator->validate($refreshToken);
            if ($errors->count() > 0) {
                foreach ($errors as $error) {
                    if ('refreshToken' === $error->getPropertyPath()) {
                        $valid = false;
                        $refreshToken->setRefreshToken();
                    }
                }
            }
        }

        $this->jwtRefresh->save($refreshToken);

        return new JsonResponse([
            'token' => $token,
            'refreshToken' => $refreshToken->getRefreshToken()
        ], 200);
    }

    /**
     * @Route("/desactivate/user", name="desactivateClient", methods={"PATCH"})
     * @param Request $request
     * @return JsonResponse
     */
    public function desactivateProfilClient(Request $request)
    {
        $data = $request->toArray();
        // if (empty($data['userId']) || empty($data['status'])) {
        //     return new JsonResponse([
        //         'message' => 'Veuillez recharger la page et reessayerle userId et status sont requis'
        //     ], 400);
        // }
        $user = $this->em->getRepository(User::class)->find((int)$data['userId']);

        if (!$user) {
            return new JsonResponse([
                'message' => 'Desolez l\'utilisateur en question n\'existe pas dans la base de donnée'
            ], 400);
        }


        $user->setStatus($data['status']);
        $this->em->persist($user);
        $this->em->flush();

        $infoUser = $this->createNewJWT($user);
        $tokenAndRefresh = json_decode($infoUser->getContent());

        return new JsonResponse([
            'token' => $tokenAndRefresh->token,
            'refreshToken' => $tokenAndRefresh->refreshToken,
        ], 200);
    }




    /**
     * @Route("/forgot/password", name="forgotPassword", methods={"POST"})
     * @param Request $request action = 1 => verifier exist numero ou email, action = 2 => send code phone, action = 3 => send code email , action = 4 => verify code
     * @return JsonResponse
     * 
     */
    public function forgotPassword(Request $request)
    {
        $data = $request->toArray();
        if (empty($data['action'])) {
            return new JsonResponse([
                'message' => 'Veuillez recharger la page et reessayeraction est requis'
            ], 400);
        }

        $action = $data['action'];
        if ($action == 1) {
            if (!empty($data['phone']) || !empty($data['email'])) {
                $user =
                    !empty($data['phone']) ? $this->em->getRepository(User::class)->findOneBy([
                        'phone' => $data['phone']
                    ]) : $this->em->getRepository(User::class)->findOneBy([
                        'email' => $data['email']
                    ]);
                if ($user) {
                    return new JsonResponse([
                        'message' => 'Utilisateur correct, veuillez poursuivre',
                        'user' => $user->getKeySecret(),
                        'status' => true
                    ], 200);
                } else {
                    return new JsonResponse([
                        'message' => 'Utilisateur inexistant',

                        'status' => false
                    ], 203);
                }
            } else {
                return new JsonResponse([
                    'message' => 'Renseigner un numero ou une adresse email',

                    'status' => false
                ], 400);
            }
        }
        if ($action == 2) {
            if (!empty($data['user'])) {
                $user =
                    $this->em->getRepository(User::class)->findOneBy([
                        'keySecret' => $data['user']
                    ]);
                if ($user) {
                    $code = $this->createCode();
                    $user->setCodeRecup($code);
                    $this->em->persist($user);
                    $this->em->flush();
                    $sendSms =   $this->sendCode($user->getPhone(), $user->getEmail(),   $code);
                    if ($sendSms) {
                        return new JsonResponse([
                            'message' => 'Le code a ete transmis veuillez consulter votre appareil',

                            'status' => true
                        ], 200);
                    } else {
                        return new JsonResponse([
                            'message' => 'Une erreur est survenue',

                            'status' => false
                        ], 203);
                    }
                } else {
                    return new JsonResponse([
                        'message' => 'Utilisateur inexistant',

                        'status' => false
                    ], 203);
                }
            } else {
                return new JsonResponse([
                    'message' => 'Renseigner un numero ou une adresse email',

                    'status' => false
                ], 400);
            }
        }
        if ($action == 3) {
            if (!empty($data['user'])) {
                $user =
                    $this->em->getRepository(User::class)->findOneBy([
                        'keySecret' => $data['user']
                    ]);
                if ($user) {
                    $code = $this->createCode();
                    $user->setCodeRecup($code);
                    $this->em->persist($user);
                    $this->em->flush();
                    $sendSms =
                        $this->sendCode(null, $user->getEmail(),   $code);
                    if ($sendSms) {
                        return new JsonResponse([
                            'message' => 'Le code a ete transmis veuillez consulter votre appareil',

                            'status' => true
                        ], 200);
                    } else {
                        return new JsonResponse([
                            'message' => 'Une erreur est survenue',

                            'status' => false
                        ], 400);
                    }
                } else {
                    return new JsonResponse([
                        'message' => 'Utilisateur inexistant',

                        'status' => false
                    ], 400);
                }
            } else {
                return new JsonResponse([
                    'message' => 'Renseigner un numero ou une adresse email',

                    'status' => false
                ], 400);
            }
        }
        if ($action == 4) {
            if (!empty($data['user']) && !empty($data['code'])) {
                $user =
                    $this->em->getRepository(User::class)->findOneBy([
                        'keySecret' => $data['user']
                    ]);
                if ($user) {


                    if (
                        $data['code']
                        == $user->getCodeRecup()
                    ) {
                        return new JsonResponse([
                            'message' => 'Le code transmis est correct',
                            'user' => $user->getKeySecret(),
                            'status' => true
                        ], 200);
                    } else {
                        return new JsonResponse([
                            'message' => 'Le code transmis est correct',

                            'status' => false
                        ], 203);
                    }
                } else {
                    return new JsonResponse([
                        'message' => 'Utilisateur inexistant',

                        'status' => false
                    ], 203);
                }
            } else {
                return new JsonResponse([
                    'message' => 'Renseigner un numero ou une adresse email',

                    'status' => false
                ], 203);
            }
        }
        if ($action == 5) {

            if (empty($data['user']) || empty($data['password'])) {
                return new JsonResponse([
                    'message' => 'Veuillez recharger la page et reessayerle user et password sont requis'
                ], 400);
            }
            $user =
                $this->em->getRepository(User::class)->findOneBy([
                    'keySecret' => $data['user']
                ]);
            if (!$user) {
                return new JsonResponse([
                    'message' => 'Desolez l\'utilisateur en question n\'existe pas dans notre base de donnée'
                ], 203);
            }
            // $npass = $this->getNewPssw();
            $user->setPassword($data['password']);
            $password = $this->passwordEncoder->encodePassword(
                $user,
                $user->getPassword()
            );
            $user->setPassword($password);
            $this->em->persist($user);
            $this->em->flush();

            $infoUser = $this->createNewJWT($user);
            $tokenAndRefresh = json_decode($infoUser->getContent());

            return new JsonResponse([
                'status' => true,
                'message' => 'Mot de passe mis a jour avec succes',
                'token' => $tokenAndRefresh->token,
                'refreshToken' => $tokenAndRefresh->refreshToken,
            ], 200);
        }
    }

    public function sendCode($phone, $email,   $code)
    {

        // $routeManager = $this->doctrine->getManager('Route');
        $message = 'Votre code de reinitilisation est : ' . $code;
        if ($phone != null) {


            $user =
                $this->em->getRepository(User::class)->findOneBy(['phone' => $phone]);
            // $contact  =   $this->createContact($user);
            $data = [
                'idClient'
                =>
                $user->getId(),
                // 'route' => $route,
                // 'contactId' =>
                // $contact['id'],
                'message' => $message,
                'senderId' =>

                'FahKap',


            ];
            $re =   $this->sendSmsApi($data);
            $this->myFunction->sendEmail(
                $email,
                $message,
                'Code de reinitialisation'
            );
            if ($re) {
                return true;
            } else {
                return false;
            }
        } else if ($email != null) {
            $this->myFunction->sendEmail(
                $email,
                $message,
                'Code de reinitialisation'
            );
            return true;
        } else {
            return false;
        }
    }


    function getPhone()
    {

        $phone = 6;
        $listeCar = '0123456789';
        $max = mb_strlen($listeCar, '8bit') - 1;
        for ($i = 0; $i < 8; ++$i) {
            $phone .= $listeCar[random_int(0, $max)];
        }
        $user =
            $this->em->getRepository(User::class)->findOneBy([
                'phone' => $phone
            ]);
        if (!$user) {
            return $phone;
        } else {
            return $this->getPhone();
        }
    }

    function getPassword()
    {

        $phone = '';
        $listeCar = '0123456789';
        $max = mb_strlen($listeCar, '8bit') - 1;
        for ($i = 0; $i < 4; ++$i) {
            $phone .= $listeCar[random_int(0, $max)];
        }

        return $phone;
    }

    public function createCode()
    {

        $code = '';
        $listeCar = '0123456789';

        for ($i = 0; $i < 4; ++$i) {
            $code .= $listeCar[random_int(0, 9)];
        }
        $ExistTransaction = $this->em->getRepository(User::class)->findOneBy(['codeRecup' => $code]);
        if ($ExistTransaction) {
            return
                $this->createCode();
        } else {
            return      $code;
        }
    }

    public function sendSmsApi($data)
    {
        //voir devoo projet
    }

    /**
     * @Route("/user/location", name="userSendLocation", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     */
    public function userSendLocation(Request $request)
    {
        $data = $request->toArray();

        if (empty($data['keySecret']) || empty($data['ville']) || empty($data['ville']) || empty($data['latitude']) || empty($data['ip'])) {
            return new JsonResponse([
                'status' => false
            ], 203);
        }
        $user = $this->em->getRepository(User::class)->findOneBy(['keySecret' => $data['keySecret']]);
        if (!$user) {
            return new JsonResponse([
                'status' => false
            ], 203);
        }

        $localisation = new Localisation();
        $localisation->setUser($user);
        $localisation->setVille($data['ville']);
        $localisation->setLongitude($data['longitude']);
        $localisation->setLatitude($data['latitude']);
        $localisation->setIp($data['ip']);
        $this->em->persist($localisation);
        $this->em->flush();

        return new JsonResponse([
            'status' => true,
        ], 200);
    }
}
