<?php

namespace App\Controller;

use App\Entity\Boutique;
use App\Entity\livreur;
use App\Entity\Produit;
use App\Entity\ProduitObject;
use App\Entity\Transaction;
use App\Entity\TypeUser;
use FFI\Exception;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\DecodingExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use App\Entity\User;
use App\FunctionU\MyFunction;

class LivreurController extends AbstractController
{

    private $em;
    private $clientWeb;

    private $myFunction;
    public function __construct(
        EntityManagerInterface $em,
        HttpClientInterface $clientWeb,
        MyFunction   $myFunction

    ) {
        $this->em = $em;
        $this->myFunction = $myFunction;

        $this->clientWeb = $clientWeb;
    }

    public function getUniqueCodeProduit()
    {


        $chaine = 'produit';
        $listeCar = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $max = mb_strlen($listeCar, '8bit') - 1;
        for ($i = 0; $i < 5; ++$i) {
            $chaine .= $listeCar[random_int(0, $max)];
        }
        $ExistCode = $this->em->getRepository(Produit::class)->findOneBy(['codeProduit' => $chaine]);
        if ($ExistCode) {
            return
                $this->getUniqueCodeProduit();
        } else {
            return $chaine;
        }
    }



    /**
     * @Route("/livreur/new", name="livreurNew", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     * @throws ClientExceptionInterface
     * @throws DecodingExceptionInterface
     * @throws RedirectionExceptionInterface
     * @throws ServerExceptionInterface
     * @throws TransportExceptionInterface
     * @throws \Exception
     * 
     * 
     * @param array $data doit contenir la  la keySecret du
     * 
     * 
     */
    public function livreurNew(Request $request)
    {

        // $typeCompte = $AccountEntityManager->getRepository(TypeCompte::class)->findOneBy(['id' => 1]);
        $data = $request->toArray();
        $possible = false;

        $serializer = $this->get('serializer');


        if (
            empty($data['keySecret']) ||
            empty($data['adminkeySecret'])

        ) {
            return new JsonResponse(
                [
                    'message' => 'Veuillez recharger la page et reessayer   '
                ],
                400
            );
        }

        $keySecret = $data['keySecret'];
        $adminkeySecret = $data['adminkeySecret'];

        $admin = $this->em->getRepository(User::class)->findOneBy(['keySecret' => $adminkeySecret]);
        $user = $this->em->getRepository(User::class)->findOneBy(['keySecret' => $keySecret]);
        if ($admin->getTypeUser()->getId() == 1) {

            if ($user) {

                $typeUser = $this->em->getRepository(TypeUser::class)->findOneBy(['id' => 3]);
                $user->setTypeUser($typeUser);

                $this->em->persist($user);
                $this->em->flush();
                return
                    new JsonResponse(
                        [
                            'message'
                            =>  'success'
                        ],
                        200
                    );
            } else {
                return
                    new JsonResponse([
                        'data'
                        => [],
                        'message' => 'Utilisateur introuvable'
                    ], 203);
            }
        } else {
            return
                new JsonResponse([
                    'data'
                    => [],
                    'message' => 'Aucune authorisation'
                ], 203);
        }
    }

    /**
     * @Route("/livreur/read/ville", name="livreurReadVille", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     * @throws ClientExceptionInterface
     * @throws DecodingExceptionInterface
     * @throws RedirectionExceptionInterface
     * @throws ServerExceptionInterface
     * @throws TransportExceptionInterface
     * @throws \Exception
     * 
     * 
     */
    public function livreurReadVille(Request $request)
    {
        $data = $request->toArray();

        $possible = false;

        $serializer = $this->get('serializer');

        $typeUser = $this->em->getRepository(TypeUser::class)->findOneBy(['id' => 3]);

        $llivreur = $this->em->getRepository(User::class)->findBy(['typeUser' => $typeUser]);

        if ($llivreur) {

            $lP = [];
            foreach ($llivreur  as $livreur) {

                $lU
                    = $this->myFunction->getUserLocalisation($livreur);
                $livreurU =  [
                    'id' => $livreur->getId(),
                    'nom' => $livreur->getNom(),
                    'prenom' => $livreur->getPrenom(),
                    'phone' => $livreur->getPhone(),
                    'distance'
                    =>  $this->myFunction->calculDistance($lU['longitude'], $lU['latitude'], $data['longitude'], $data['latitude']),


                ];
                array_push($lP, $livreurU);
            }
            $llivreurF = $serializer->serialize($lP, 'json');

            return
                new JsonResponse(
                    [
                        'data'
                        => JSON_DECODE($llivreurF)
                    ],
                    200
                );
        } else {
            return
                new JsonResponse([
                    'data'
                    => [],
                    'message' => 'Aucun produit'
                ], 203);
        }
    }
    /**
     * @Route("/livreur/read/all", name="livreurReadAll", methods={"POST"})
     * @param Request $request
     * @return JsonResponse
     * @throws ClientExceptionInterface
     * @throws DecodingExceptionInterface
     * @throws RedirectionExceptionInterface
     * @throws ServerExceptionInterface
     * @throws TransportExceptionInterface
     * @throws \Exception
     * 
     * 
     */
    public function livreurReadAll(Request $request)
    {

        $possible = false;

        $serializer = $this->get('serializer');


        $llivreur = $this->em->getRepository(User::class)->findAll();

        if ($llivreur) {

            $lP = [];
            foreach ($llivreur  as $livreur) {

                $livreur =  [
                    'id' => $livreur->getId(),
                    'nom' => $livreur->getNom(),
                    'prenom' => $livreur->getPrenom(),
                    'phone' => $livreur->getPhone(),
                    'localisation' =>
                    $this->myFunction->getUserLocalisation($livreur),


                ];
                array_push($lP, $livreur);
            }
            $llivreurF = $serializer->serialize($lP, 'json');

            return
                new JsonResponse(
                    [
                        'data'
                        => JSON_DECODE($llivreurF)
                    ],
                    200
                );
        } else {
            return
                new JsonResponse([
                    'data'
                    => [],
                    'message' => 'Aucun produit'
                ], 203);
        }
    }
}
